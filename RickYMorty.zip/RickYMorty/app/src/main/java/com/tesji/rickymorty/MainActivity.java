package com.tesji.rickymorty;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import com.bumptech.glide.Glide;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {
    private EditText personaje;
    private Button consulta;
    private TextView datos;
    private Button Salir;
    private MediaPlayer sonidoBoton;
    private ImageView gifImageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        personaje = findViewById(R.id.Personaje);
        consulta = findViewById(R.id.Consultar);
        datos = findViewById(R.id.Datos);
        Salir = findViewById(R.id.Salir);
        gifImageView = findViewById(R.id.gifImageView);

        consulta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Reproducir sonido al hacer clic en el botón
                reproducirSonido();

                // Obtener ID del personaje ingresado por el usuario
                String characterId = personaje.getText().toString().trim();
                // Llamar a AsyncTask para obtener datos del personaje
                new Personaje().execute(characterId);
            }
        });

        Salir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        // Cargar el GIF utilizando Glide
        Glide.with(this)
                .load(R.drawable.real)
                .into(gifImageView);
    }


    private void reproducirSonido() {
        sonidoBoton = MediaPlayer.create(getApplicationContext(), R.raw.beeplil);
        sonidoBoton.start();
    }

    private class Personaje extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... params) {
            String characterId = params[0];
            String apiUrl = "https://rickandmortyapi.com/api/character/" + characterId;

            try {
                URL url = new URL(apiUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");

                int responseCode = connection.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    InputStream inputStream = connection.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }
                    reader.close();
                    return response.toString();
                } else {
                    return "Error: " + responseCode;
                }
            } catch (IOException e) {
                e.printStackTrace();
                return "Error: " + e.getMessage();
            }
        }

        @Override
        protected void onPostExecute(String result) {
            try {
                JSONObject jsonObject = new JSONObject(result);
                String name = jsonObject.getString("name");
                String status = jsonObject.getString("status");
                String species = jsonObject.getString("species");
                String gender = jsonObject.getString("gender");
                String imageUrl = jsonObject.getString("image");


                Glide.with(MainActivity.this)
                        .load(imageUrl)
                        .into(gifImageView);

                String characterData = "Nombre: " + name + "\n"
                        + "Estado: " + status + "\n"
                        + "Especie: " + species + "\n"
                        + "Género: " + gender;

                datos.setText(characterData);
            } catch (JSONException e) {
                e.printStackTrace();
                datos.setText("No exite el personaje \nintenta de nuevo");
            }
        }
    }
}